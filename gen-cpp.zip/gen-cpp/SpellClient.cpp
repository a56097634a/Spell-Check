#include "SpellService.h"

#include <thrift/transport/TSocket.h>
#include <thrift/transport/TBufferTransports.h>
#include <thrift/protocol/TBinaryProtocol.h>
//#include <boost/thread.hpp>
//#include <boost/date_time.hpp>

#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <random>

using namespace apache::thrift;
using namespace apache::thrift::protocol;
using namespace apache::thrift::transport;

using namespace SpellServer;
int main(int argc, char **argv){
    //if not enough input, return
    if(argc <= 3) return -1;
    //reading server list
    std::vector<std::string> serverList;
    std::ifstream inputStream;
    inputStream.open(argv[1]);
    std::string server;
    std::string lastline = "";
    while(true){
        getline(inputStream, server);
        if(server != lastline){
            std::cout << server << std::endl;
            serverList.push_back(server);
        }
        else{
            printf("server list loaded\n");
            break;
        }
    }
    
    //get the input words into request
    SpellRequest request;
    SpellResponse response;
    for(int i = 3; i < argc; i++){
        std::string input = std::string(argv[i]);
        //std::cout<< input <<std::endl;
        request.to_check.push_back(input);
    }
    
    //time out configure
    
    int timeOut = atoi(argv[2]);
    
    //randomize the server list
    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(serverList.begin(), serverList.end(), g);
    
    //get server IP from serverList, the port is defined as the same
    for (std::vector<std::string>::iterator i = serverList.begin(); i != serverList.end(); i++) {
        std::istringstream buf(*i);
        std::istream_iterator<std::string> beg(buf), end;
        std::vector<std::string> tokens(beg, end);
        boost::shared_ptr<TSocket> socket(new TSocket(tokens[0], atoi(tokens[1].c_str())));
#pragma mark - timeOut setting
        socket->setConnTimeout(100);
        socket->setSendTimeout(100);
        socket->setRecvTimeout(timeOut * 1000);
        boost::shared_ptr<TTransport> transport(new TBufferedTransport  (socket));
        boost::shared_ptr<TProtocol> protocol(new TBinaryProtocol(transport));
        SpellServiceClient client(protocol);
        //handle TCP connection error with 100ms time out
        try {
            std::cout << "connecting " + *i /*<< e.what()*/ << std::endl;
            transport -> open();
        } catch (TTransportException &e) {
            printf("open error...changing server...\n");
            continue;
        }
        
        //RPC call to the server
        printf("requesting... \n");
        try {
            client.spellcheck(response, request);
        } catch (TTransportException &e) {
            std::cout << e.what() << std::endl;
            printf("server busy... changing server...\n");
            if (transport->isOpen()) {
                transport -> close();
            }
            continue;
        }
        
        //Output the response
        printf("responsing... \n");
        for(int i = 0; i < response.is_correct.size(); i++){
            std::cout << response.is_correct[i] << " ";
        }
        std::cout << std::endl;
        transport -> close();
        return 0;
        }
    return 1;
}

